#include <stdio.h>
#include <stdlib.h>
#include "Arvore_Naria.h"

int main()
{
    //passa um número da chave para a arvore, pode ser qualquer numero
    PONT r = inicializa(8);

    return 0;
}

