#include <stdio.h>
#include <stdlib.h>
#include "AVL.h"

int main()
{
    PONT r = inicializa();

    return 0;
}
