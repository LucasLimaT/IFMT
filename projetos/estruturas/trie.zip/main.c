#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "trie.h"

int main()
{
    PONT r = inicializa();

    return 0;
}
